# server.py
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import importlib
import os

app = Flask(__name__)
CORS(app)  # allow local JS access

# -------------------------------
# Load your AI agent dynamically
# -------------------------------
try:
    ai_agent = importlib.import_module("agent_stub")  # replace with real agent module later
    print("Agent module loaded")
except ImportError:
    print("⚠️ Agent not found, using dummy responses")

# -------------------------------
# Chat history
# -------------------------------
history = []

# -------------------------------
# Serve index.html at /
# -------------------------------
@app.route("/")
def index():
    return send_from_directory(".", "index.html")

# -------------------------------
# Serve static files (background, sounds)
# -------------------------------
@app.route("/<path:filename>")
def static_files(filename):
    if os.path.exists(filename):
        return send_from_directory(".", filename)
    return "File not found", 404

# -------------------------------
# Chat endpoint
# -------------------------------
@app.route("/chat", methods=["POST"])
def chat_endpoint():
    global history
    data = request.get_json()
    user_message = data.get("message", "").strip()
    if not user_message:
        return jsonify({"reply": "No message sent."})

    # store user message
    history.append({"role": "user", "content": user_message})

    # call AI agent
    try:
        if "ai_agent" in globals():
            # agent must provide agent_reply(user_message, history)
            reply = ai_agent.agent_reply(user_message, history)
        else:
            reply = f"Stub reply: {user_message[::-1]}"  # just reverse input for testing
    except Exception as e:
        reply = f"Error calling agent: {e}"

    # store AI reply
    history.append({"role": "assistant", "content": reply})

    return jsonify({"reply": reply})

# -------------------------------
# Start server
# -------------------------------
if __name__ == "__main__":
    print("Starting Flask server at http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000)
