# agent_stub.py

def agent_reply(user_message, history=None):
    """
    Dummy agent for testing.
    Just echoes the input with a prefix.
    """
    return f"[Agent says]: {user_message}"
